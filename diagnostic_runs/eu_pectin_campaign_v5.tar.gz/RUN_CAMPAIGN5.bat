@echo off
rem Launch the parallel MOPAC campaign v2 (PM7 / Sparkle Eu(III), gas-phase microsolvated clusters, frozen O-H)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_campaign5.ps1" -MaxParallel 13 -MaxRestarts 4 -Root "%CD%" -CampaignDir campaign5
echo.
echo Campaign v5 finished. You can close this window.
pause
