# Parallel MOPAC campaign runner (Windows PowerShell)
# Runs every campaign\<job>\<job>.mop that has not finished yet, MaxParallel at a time.
param(
    [int]$MaxParallel = 12,
    [string]$Root = $PSScriptRoot,
    [string]$CampaignDir = "campaign"
)
$ErrorActionPreference = "Continue"
$mopac = Join-Path $Root "_tools\mopac-23.2.5-win\bin\mopac.exe"
if (-not (Test-Path $mopac)) { Write-Host "MOPAC not found at $mopac"; exit 1 }
$camp = Join-Path $Root $CampaignDir
$log = Join-Path $camp "progress.log"
$env:OMP_NUM_THREADS = "2"
$env:MKL_NUM_THREADS = "2"

function Is-Done($outFile) {
    if (-not (Test-Path $outFile)) { return $false }
    return (Select-String -Path $outFile -Pattern "ended normally|JOB ENDED NORMALLY|== MOPAC DONE ==" -Quiet)
}

$jobs = @()
Get-ChildItem -Path $camp -Directory | Sort-Object Name | ForEach-Object {
    $mop = Get-ChildItem -Path $_.FullName -Filter *.mop | Select-Object -First 1
    if ($mop) {
        $out = Join-Path $_.FullName ($mop.BaseName + ".out")
        if (-not (Is-Done $out)) {
            $jobs += [pscustomobject]@{ Dir = $_.FullName; Mop = $mop.Name; Name = $mop.BaseName; Out = $out }
        }
    }
}
# controls first (small), then the rest
$jobs = @($jobs | Where-Object { $_.Name -like "CTRL_*" }) + @($jobs | Where-Object { $_.Name -notlike "CTRL_*" })
"$(Get-Date -Format s) START: $($jobs.Count) pending jobs, MaxParallel=$MaxParallel" | Tee-Object -FilePath $log -Append

$running = @{}
$queue = [System.Collections.Queue]::new()
$jobs | ForEach-Object { $queue.Enqueue($_) }
$t0 = Get-Date
while ($queue.Count -gt 0 -or $running.Count -gt 0) {
    # reap finished
    foreach ($k in @($running.Keys)) {
        $p = $running[$k].Proc
        if ($p.HasExited) {
            $dt = [int]((Get-Date) - $running[$k].Start).TotalSeconds
            "$(Get-Date -Format s) DONE  $k  exit=$($p.ExitCode)  ${dt}s" | Tee-Object -FilePath $log -Append
            $running.Remove($k)
        }
    }
    # launch new
    while ($running.Count -lt $MaxParallel -and $queue.Count -gt 0) {
        $j = $queue.Dequeue()
        if (Test-Path $j.Out) { Remove-Item $j.Out -Force }
        $p = Start-Process -FilePath $mopac -ArgumentList $j.Mop -WorkingDirectory $j.Dir -WindowStyle Hidden -PassThru
        $running[$j.Name] = @{ Proc = $p; Start = (Get-Date) }
        "$(Get-Date -Format s) START $($j.Name)" | Tee-Object -FilePath $log -Append
    }
    Start-Sleep -Seconds 5
}
$el = [int]((Get-Date) - $t0).TotalMinutes
"$(Get-Date -Format s) ALL DONE in $el min" | Tee-Object -FilePath $log -Append
