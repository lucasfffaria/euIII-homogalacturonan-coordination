@echo off
rem Launch the parallel MOPAC campaign (PM7 / Sparkle Eu(III) / COSMO)
cd /d "%~dp0"
echo Testing MOPAC ...
cd _tools\mopac-23.2.5-win\examples
..\bin\mopac.exe example_scf.mop
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_campaign.ps1" -MaxParallel 12 -Root "%CD%"
echo.
echo Campaign finished. You can close this window.
pause
